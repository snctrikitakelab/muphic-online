enchant();

var Start = enchant.Class.create(enchant.Sprite,{
    initialize:function(x,y){
        enchant.Sprite.call(this,128,128);
        this.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/Buttons.gif'];
        this.x = x;
        this.y = y;
        this.scaleX = 0.8;
        this.scaleY = 0.8;
        this.frame = 0;
//        this.mode = 0;
        this.addEventListener('touchstart',this.chmod);
        this.mode = 0;
    },
    
    chmod:function(){
        if(this.mode == 0){
            this.frame = 1;
        }
        else{
            this.frame = 0;
        }
    }
});
        
    
    
window.onload = function(){
	game = new Game(802,601);
	game.preload('http://www42413u.sakura.ne.jp/~okawa/test/background.jpg','http://www42413u.sakura.ne.jp/~okawa/test/background2.jpg','http://www42413u.sakura.ne.jp/~okawa/test/Buttons.gif');
	
	game.onload = function(){
        
        //背景の生成
		var background = new Sprite(802,601);
        var background2 = new Sprite(608,363);
		background.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/background.jpg'];
        background2.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/background2.jpg'];
        background2.x=90;
        background2.y=200;
        
        //startボタンの生成
        start = new Start(400,20);
        
        //stopボタンの生成
        //var stop = new Stop();
        
        //deleteボダンの生成
        //var delete = new Delete();
       
        game.rootScene.addChild(background);
        game.rootScene.addChild(background2);
        game.rootScene.addChild(start);
	};
	game.start();
};