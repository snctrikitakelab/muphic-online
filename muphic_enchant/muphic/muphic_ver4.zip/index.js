enchant();


var Background2 = enchant.Class.create(enchant.Sprite,{
    initialize:function(x,y){
        enchant.Sprite.call(this,610,350);
        this.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/background2.jpg'];
        this.x = x;
        this.y = y;
        this.addEventListener('touchstart',this.onpu);
    },
    
    //音符配置
    onpu:function(e){
        if(chanimal !== null){
	        var setonpu = new Setonpu(e.localX,e.localY);
    	    game.rootScene.addChild(setonpu);
        }
    } 
    
});

var Setonpu = enchant.Class.create(enchant.Sprite,{
    initialize:function(x,y){
        enchant.Sprite.call(this,73,50);
        this.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/Animal.png'];
        this.frame = chanimal;
        ex = x+90;
        ey = y+200;
        for(i = 0;i < 13;i++){
            if((50*i+90) > ex){ 
                ex = 50*i+90;
                break;
            }
        }
        for(j = 0;j < 10;j++){
            if((40*j+200) > ey){
                ey = 40*j+200;
                break;
            }
        }
        this.x = ex-50-25;
        this.y = ey-40-18;
        this.scaleX = 0.8;
        this.scaleY = 0.8;
    }
});

var Start = enchant.Class.create(enchant.Sprite,{
    initialize:function(x,y){
        enchant.Sprite.call(this,128,128);
        this.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/Buttons.png'];
        this.x = x;
        this.y = y;
        this.scaleX = 0.8;
        this.scaleY = 0.8;
        this.frame = 0;
        this.addEventListener('touchstart',this.chf);
    },
    
    chf:function(){
        if(this.frame === 0){
            this.frame = 1;
        }
        else{
            this.frame = 0;
        }
    }
});

var Stop = enchant.Class.create(enchant.Sprite,{
    initialize:function(x,y){
        enchant.Sprite.call(this,128,128);
        this.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/Buttons.png'];
        this.x = x;
        this.y = y;
        this.scaleX = 0.8;
        this.scaleY = 0.8;
        this.frame = 2;
        this.addEventListener('touchstart',function(){
            this.frame = 3;
        });
        this.addEventListener('touchend',function(){
            this.frame = 2;
        });
    }
});

var Delete = enchant.Class.create(enchant.Sprite,{
    initialize:function(x,y){
        enchant.Sprite.call(this,128,128);
        this.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/Buttons.png'];
        this.x = x;
        this.y = y;
        this.scaleX = 0.8;
        this.scaleY = 0.8;
        this.frame = 4;
        this.addEventListener('touchstart',this.chf);
    },
    
    chf:function(){
        if(this.frame === 4){
            this.frame = 5;
        }
        else{
            this.frame = 4;
        }
    }
});

var S_Button = enchant.Class.create(enchant.Sprite,{
    initialize:function(x,y,frame,scaleX,scaleY){
        enchant.Sprite.call(this,84,44);
        this.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/Buttons_char.png'];
        this.x = x;
        this.y = y;
        this.scaleX = scaleX;
        this.scaleY = scaleY;
        this.frame = frame;
         
    }
});

var Animal = enchant.Class.create(enchant.Sprite,{
    initialize:function(x,y,frame){
        enchant.Sprite.call(this,73,50);
        this.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/Animal.png'];
        this.x = x;
        this.y = y;
        this.frame = frame;
        
        this.addEventListener('touchstart',function(){
            if(p%2 == 1){
                if(p != 1){
                    game.rootScene.removeChild(sel2);
                }
            }else{
                game.rootScene.removeChild(sel);
            }
        });
        
        this.addEventListener('touchend',function(){
            if(p%2 == 1){
	            sel = new Select(this.frame,20,610);
                game.rootScene.addChild(sel);
                p++;
            }else{
	            sel2 = new Select(this.frame,20,610);
                game.rootScene.addChild(sel2);
                p++;
            }
            
        });
    }
});

var Select = enchant.Class.create(Animal,{
    initialize:function(frame,x,y){
        Animal.call(this,73,50);
        this.frame = frame;
        chanimal = frame;
        this.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/Animal.png'];
        this.x = x;
        this.y = y;
    }
    
    
});

    
window.onload = function(){
	game = new Game(802,700);
	game.preload('http://www42413u.sakura.ne.jp/~okawa/test/background.jpg','http://www42413u.sakura.ne.jp/~okawa/test/background2.jpg','http://www42413u.sakura.ne.jp/~okawa/test/Buttons.png'
                ,'http://www42413u.sakura.ne.jp/~okawa/test/Buttons_char.png','http://www42413u.sakura.ne.jp/~okawa/test/Animal.png');
    
    p = 1;
    chanimal = null;
	
	game.onload = function(){
             
        //背景の生成
		var background = new Sprite(802,700);
		background.image = game.assets['http://www42413u.sakura.ne.jp/~okawa/test/background.jpg'];
        background2 = new Background2(90,200);
        
        //startボタンの生成
        start = new Start(400,20);
        
        //stopボタンの生成
        stop = new Stop(510,20);
        
        //deleteボタンの生成
        del = new Delete(620,20);
        
        //音ボタンの生成
        
        sel_button = new S_Button(20,620,0,1.5,2);
        
        button_s = new S_Button(120,620,0,1,1.5);
        sheep = new Animal(120,610,0);
        
        button_r = new S_Button(220,620,1,1,1.5);
        rabbit = new Animal(220,610,1);
        
        button_b = new S_Button(320,620,2,1,1.5);
        bird = new Animal(320,610,2);
        
        button_d = new S_Button(420,620,3,1,1.5);
        dog = new Animal(420,610,3);
        
        button_p = new S_Button(520,620,4,1,1.5);
        pig = new Animal(520,610,4);
        
        button_c = new S_Button(620,620,0,1,1.5);
        cat = new Animal(620,610,5);
        
        game.rootScene.addChild(background);
        game.rootScene.addChild(background2);
        game.rootScene.addChild(start);
        game.rootScene.addChild(stop);
        game.rootScene.addChild(del);
        game.rootScene.addChild(sel_button);
        game.rootScene.addChild(button_s);
        game.rootScene.addChild(sheep);
        game.rootScene.addChild(button_r);
        game.rootScene.addChild(rabbit);
        game.rootScene.addChild(button_b);
        game.rootScene.addChild(bird);
        game.rootScene.addChild(button_d);
        game.rootScene.addChild(dog);
        game.rootScene.addChild(button_p);
        game.rootScene.addChild(pig);
        game.rootScene.addChild(button_c);
        game.rootScene.addChild(cat);
	};
	game.start();
};