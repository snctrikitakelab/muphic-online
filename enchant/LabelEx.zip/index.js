enchant();
window.onload = function(){
    //ゲームオブジェクトの生成
    var game = new Game(320,320);
    
    //FPSの指定
    game.fps=16;
    
    //ラベルの追加
    game.addLabel = function(text,color,x,y){
        //ラベルの生成
        var label = new Label(text);
        label.font = "16px monospace";
        label.color = color;
        label.x = x;
        label.y = y;
        game.rootScene.addChild(label);
        
        //ラベルの定期処理
        label.tick = 0;
        label.addEventListener(Event.ENTER_FRAME,function(){
            label.y --;
            label.tick ++;
            
            //ラベルの削除
            if(label.tick > 10) game.rootScene.removeChild(label);
        });
    };
    
    //シーンの定期処理
    game.tick = 0;
    game.rootScene.addEventListener(Event.ENTER_FRAME,function(){
        if((game.tick%3) === 0){
            var score = rand(100);
            var r = rand(256);
            var g = rand(256);
            var b = rand(256);
            var x = rand(300);
            var y = rand(300);
            game.addLabel(score + "点","rgb(" + r + " , " + g + " , " + b + ")", x, y);
        }
        game.tick++;
    });
    
    //ゲームの開始
    game.start();
};

//乱数の発生
function rand(num){
    return Math.floor(Math.random() * num);
}